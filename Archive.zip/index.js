const Alexa = require('ask-sdk');
const getmp3 = require ("./getmp3.js");


const LaunchRequestHandler = {
	canHandle(handlerInput) {
		return (handlerInput.requestEnvelope.request.type === 'LaunchRequest') 
		|| (handlerInput.requestEnvelope.request.type === 'IntentRequest'
      	&& handlerInput.requestEnvelope.request.intent.name === 'AMAZON.ResumeIntent');
	},
	async handle(handlerInput) {
		// const speechText = 'Welcome!! hello!! you are here!';
		const mp3 = await getmp3()
		return handlerInput.responseBuilder
		.addAudioPlayerPlayDirective("REPLACE_ALL", 
			mp3, 
			"type whatever you want", 
			0)
		.withSimpleCard("Welcome to The Atlantic's Daily Idea")
		.getResponse();
		}
}

 // quit, stop, pause

const PauseIntentHandler = {
 	canHandle(handlerInput) {
    	return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      	&& handlerInput.requestEnvelope.request.intent.name === 'AMAZON.PauseIntent';
  	},
		handle(handlerInput) {
   		return handlerInput.responseBuilder
      	.addAudioPlayerStopDirective()
      	.getResponse();
      }
}

// start over, repeat - same as launch

// const StartOverRequestHandler = {
// 	canHandle(handlerInput) {
// 		return handlerInput.requestEnvelope.request.type === 'IntentRequest'
//         && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StartOverIntent';
// 	},
// 	async handle(handlerInput) {
// 		// const speechText = 'Welcome!! hello!! you are here!';
// 		const mp3 = await getmp3()
// 		return handlerInput.responseBuilder
// 		.addAudioPlayerPlayDirective("REPLACE_ALL", 
// 			mp3, 
// 			mp3, 
// 			0)
// 		.withSimpleCard("Welcome to The Atlantic's Daily Idea")
// 		.getResponse();
// 		}
// }

// next

const NextIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.NextIntent';
  },
  async handle(handlerInput) {
    const mp3 = await getmp3()

    return handlerInput.responseBuilder
      	.addAudioPlayerPlayDirective("REPLACE_ALL", 
        user.currentArticle, 
        user.currentArticle, 
        0)
		// .withSimpleCard("Welcome to The Atlantic's Daily Idea")
		.getResponse();
		}
}




	
const skillBuilder = Alexa.SkillBuilders.custom();

exports.handler = skillBuilder
	.addRequestHandlers(
		LaunchRequestHandler, PauseIntentHandler
		)
	.lambda();